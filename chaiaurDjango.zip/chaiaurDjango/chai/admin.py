from django.contrib import admin
from .models import ChaiVarity, Chai_Review, store, Chai_Certificate

# Register your models here.

class Chai_Review_InLine(admin.TabularInline):
    model = Chai_Review
    extra = 2

class Chai_Verity_Admin(admin.ModelAdmin):
    list_display = ['name', 'type', 'date_added']
    inlines = [Chai_Review_InLine]

class Store_Admin(admin.ModelAdmin):
    list_display = ['name', 'location']
    filter_horizontal = ['chai_varities']

class Chai_Certificate_Admin(admin.ModelAdmin):
    list_display = ['chai', 'certificate_number', 'issue_date', 'valid_till']

admin.site.register(ChaiVarity, Chai_Verity_Admin)
admin.site.register(store, Store_Admin)
admin.site.register(Chai_Certificate, Chai_Certificate_Admin)
